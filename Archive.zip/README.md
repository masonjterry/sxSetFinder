** sxSetFinder 
