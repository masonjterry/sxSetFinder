module.exports = {
  TestSchema: require("./test")
}
