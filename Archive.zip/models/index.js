module.exports = {
  Credentials: require("./test")
}
